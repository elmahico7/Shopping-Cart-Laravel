

<?php $__env->startSection('title'); ?>
    Laravel Shopping Cart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('cart')): ?>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <ul class="list-group">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <span class="badge"><?php echo e($product['qty']); ?></span>
                                <strong><?php echo e($product['item']['title']); ?></strong>
                                <span class="label label-success"><?php echo e($product['price']); ?></span>
                                <div class="clearfix">
                                </div>
                                <li><a href="<?php echo e(route('product.reduceByOne', ['id' => $product['item']['id']])); ?>"> Reduce by 1</a></li>
                                
                            </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
            	 <?php if($totalPrice <= 100): ?>
                <strong>Total:  <?php echo e((5*$weight + $totalPrice)); ?> (Make a purchase over 100$ and you will have a discount of 10%!. On the Total Price is included an extra fee for the weight (5 * weight)</strong> 
                <?php elseif($totalPrice > 100): ?>
                <strong>Total: <?php echo e(5*$weight + $totalPrice - 0.1*$totalPrice); ?> You have a discount of 10%! (On the Total Price is included an extra fee for the weight (5 * weight)</strong> 
            <?php endif; ?>    
         	
            </div>
        </div>
        <hr>
       
    <?php else: ?>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <h2>No Items in Cart!</h2>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping-cart\resources\views/shop/shopping-cart.blade.php ENDPATH**/ ?>