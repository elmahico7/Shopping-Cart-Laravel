<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo e(route('product.index')); ?>">Products</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('product.shoppingCart')); ?>"><i class="fa fa-shopping-cart"> </i> Shopping Cart <span class="badge"> <?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : ''); ?></span></a>
      </li>
    </ul>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\shopping-cart\resources\views/partials/header.blade.php ENDPATH**/ ?>