<?php

use Illuminate\Database\Seeder;

class ProductTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $product = new \App\Product([
        	'imagePath' => 'http://ecx.images-amazon.com/images/I/51ZU%2BCvkTyL.jpg',
        	'title' => 'Harry Potter',
        	'description' => 'Super Cool',
        	'price' => 30,
        	'weight'=> 0.5
        ]);
        $product->save();
        $product = new \App\Product([
        	'imagePath' => 'http://ecx.images-amazon.com/images/I/81TWKUr9NnL.jpg',
        	'title' => 'Choki',
        	'description' => 'Girls',
        	'price' => 40,
        	'weight'=> 0.2
        ]);
        $product->save();
        $product = new \App\Product([
        	'imagePath' => 'http://ecx.images-amazon.com/images/I/41Gm9b-QqXL.jpg',
        	'title' => 'iPhone',
        	'description' => 'Plus',
        	'price' => 300,
        	'weight'=> 0.8
        ]);
        $product->save();
    }
}
