@extends('layouts.master')

@section('title')
    Laravel Shopping Cart
@endsection

@section('content')
    @if(Session::has('cart'))
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <ul class="list-group">
                    @foreach($products as $product)
                            <li class="list-group-item">
                                <span class="badge">{{ $product['qty'] }}</span>
                                <strong>{{ $product['item']['title'] }}</strong>
                                <span class="label label-success">{{ $product['price'] }}</span>
                                <div class="clearfix">
                                </div>
                                <li><a href="{{ route('product.reduceByOne', ['id' => $product['item']['id']]) }}"> Reduce by 1</a></li>
                                
                            </li>

                    @endforeach
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
            	 @if($totalPrice <= 100)
                <strong>Total:  {{ (5*$weight + $totalPrice) }} (Make a purchase over 100$ and you will have a discount of 10%!. On the Total Price is included an extra fee for the weight (5 * weight)</strong> 
                @elseif($totalPrice > 100)
                <strong>Total: {{ 5*$weight + $totalPrice - 0.1*$totalPrice }} You have a discount of 10%! (On the Total Price is included an extra fee for the weight (5 * weight)</strong> 
            @endif    
         	
            </div>
        </div>
        <hr>
       
    @else
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <h2>No Items in Cart!</h2>
            </div>
        </div>
    @endif
@endsection